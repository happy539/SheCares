import random 
quotes=['I have not failed, I have just found 10,000 ways that won\'t work','Let\'s go invent tommorow instead of worrying about what happened yesterday.','The great growling engine of change – technology.','The technology you use impresses no one. The experience you create with it is everything.','Recognize and embrace your uniqueness...Being a Black woman, being a woman in general, on a team of all men, means that you are going to have a unique voice. It\'s important to embrace that.']
answer = input ("Do you want to play games or quotes?(Type joke or quote)")

if answer == 'joke': 
  print("Welcome to the Jokes Corner! What\'s your name?",end= ' ')
  name = input()
  print('Hey '+ name+' try to guess the answers for these jokes!')
  print()
  print('What did the spider do on the computer?')
  guess = input()
  answerFirst= 'Made a website' 
  if guess == answerFirst: 
    print('WOW! Good job you did it!')
  else: 
    print('Oops!The correct answer is '+answerFirst)
  print ()
  print("What did the computer do at lunchtime?")
  guess= input()
  answerSec= 'It had a byte'

  if guess == answerSec:
      print('Correct!, the right answer is '+ answerSec)
      
  else:
      print("Good try, but the right answer answer is "+ answerSec)
  print()
  print("Why did the computer kept sneezing?")
  guess= input()
  answerThird='It had a virus'

  if guess == answerThird:
      print("Correct!, the right answer is "+ answerThird)
      
  else:
      print("Good try, but the right answer answer is "+ answerThird)
  print()
  print('Why was the computer cold?')#print()adds a newline character to the end of the string it prints
  guess= input()
  answerFourth= 'It left the window open'

  if guess == answerFourth:
      print('Correct!, the right answer is ',answerFourth)
      print(answerFourth)
      
  else:
      print('Good try, but the right answer answer is '+ answerFourth)

elif answer == 'quote': 
  name = input ("Hello, what\'s your name?")
  print ("Hi "+ name + "! Welcome to Quotemania")
  print(random.choice(quotes))
  i = str(input("Press 'a' for another quote or presss 'b' to quit "))
  if i == 'a': 
    print(random.choice(quotes))
    i = str(input("Press 'a' for another quote or press 'b' to quit "))

  elif i == 'b': 
    quit()
