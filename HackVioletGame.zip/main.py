#Classes
import pygame
import time
import random
import os 

#Main Function
def main(): 

    #Initializing Pygame
    pygame.init()
    screen = pygame.display.set_mode((400,300))
    pygame.event.get()
    end = False

    #Colors
    green = (0,200,0)
    black = (0,0,0)
    red = (255,0,0)
    blue = (0,0,128)
    gray = (200,200,200)
    coffee_brown =((200,190,140))
    moon_glow = ((235,245,255))
    tan = ((230,220,170))
    lime = ((180,255,100))
    purple = ((230,0,255))
    rust = ((210,150,75))
    white = (255,255,255)

    #Screen dimensions
    dis_width = 800
    dis_height = 600

    #Paddle positions
    x = dis_width - 780
    y = dis_height/2

    x2 = dis_width - 35 
    y2 = dis_height/2

    #Divider positions
    div_x = dis_width/2
    div_y = 0

    #Wall positions
    wall_1_x = 0
    wall_1_y = 0
    wall_2_x = 790
    wall_2_y = 0
    wall_3_x = 0
    wall_3_y = 0
    wall_4_x = 0
    wall_4_y = 590

    #Ball position
    x_ball = dis_width/2
    y_ball = dis_height/2 

    #Changing paddle positions
    x_change = 0
    y_change = 0

    x2_change = 0
    y2_change = 0

    #Changing ball position
    x_ball_change = random.randrange(-20,20)
    y_ball_change = random.randrange(-20,20) 

    #Scores
    score_a = 0
    score_b = 0

    #Setting up display
    dis = pygame.display.set_mode((dis_width, dis_height))
    pygame.display.set_caption("Pong")
    clock = pygame.time.Clock()

    

  

    #Main loop
    while not end:

        #Quitting
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                end = True 
            #Function of key presses
            if event.type == pygame.KEYDOWN:
                pressed = pygame.key.get_pressed()
                if pressed[pygame.K_UP]:
                    x2_change = 0
                    y2_change = -10
                if pressed[pygame.K_DOWN]:
                    x2_change= 0
                    y2_change = 10
                if pressed[pygame.K_w]:
                    x_change = 0
                    y_change = -10
                if pressed[pygame.K_d]:
                    x_change = 0
                    y_change = 10 
        #Moving the paddles 
        x += x_change
        y += y_change
        x2 += x2_change
        y2 += y2_change
        dis.fill(black)
        clock.tick(15)

        #Displaying score
        font = pygame.font.Font(None,74)
        text = font.render(str(score_a),True,white)
        screen.blit(text,(200,10))
        text = font.render(str(score_b),True,white)
        screen.blit(text,(600,10))

        #Drawing the paddles 
        p_pong = pygame.draw.rect(screen,purple,pygame.Rect(x,y,15,75))
        b_pong = pygame.draw.rect(screen,blue,pygame.Rect(x2,y2,15,75))

        #Drawing the divider 
        divider = pygame.draw.rect(screen,white,pygame.Rect(div_x,div_y,10,dis_height))
        
        #Drawing the ball 
        ball = pygame.draw.rect(screen,red,pygame.Rect(x_ball,y_ball,20,20))   

        #Drawing the walls 
        wall_1 = pygame.draw.rect(screen,lime,pygame.Rect(wall_1_x,wall_1_y,10,dis_height))
        wall_2 = pygame.draw.rect(screen,lime,pygame.Rect(wall_2_x,wall_2_y,10,dis_height))
        wall_3 = pygame.draw.rect(screen,lime,pygame.Rect(wall_3_x,wall_3_y,dis_width,10))
        wall_4 = pygame.draw.rect(screen,lime,pygame.Rect(wall_4_x,wall_4_y,dis_width,10))
        pygame.display.flip()
                                              
            
        #Keeping paddles inside the boundaries 
        if pygame.Rect.colliderect(p_pong,wall_3):
            x_change = 0
            y_change = 15
            x += x_change 
            y += y_change
        elif pygame.Rect.colliderect(p_pong,wall_4):
            x_change = 0
            y_change = -15
            x += x_change
            y += y_change
     
        if pygame.Rect.colliderect(b_pong,wall_3):
            x2_change = 0
            y2_change = 15
            x2 += x2_change 
            y2 += y2_change
        elif pygame.Rect.colliderect(b_pong,wall_4):
            x2_change = 0
            y2_change = -15
            x2 += x2_change
            y2 += y2_change

            
        x_ball += x_ball_change
        y_ball += y_ball_change

        #Keeping ball inside the boundaries 

        if pygame.Rect.colliderect(ball,wall_3):
            y_ball_change = 15
            x_ball += 10
            y_ball += y_ball_change
        if pygame.Rect.colliderect(ball,wall_4):
            y_ball_change = -15
            x_ball += 10
            y_ball += y_ball_change

        elif pygame.Rect.colliderect(ball,p_pong):
            x_ball_change = 15
            y_ball_change = 5
            x_ball += x_ball_change
            y_ball += y_ball_change

        elif pygame.Rect.colliderect(ball,b_pong):
            x_ball_change = -15
            y_ball_change = -5
            x_ball += x_ball_change
            y_ball += y_ball_change

        #Increasing score
        if 0 >= x_ball and score_a < 10:
            score_b_change = 1
            score_b += score_b_change
            x_ball_change = 15
            y_ball += 1
            x_ball += x_ball_change

        elif x_ball >= 790 and score_b < 10:
            score_a_change = 1
            score_a += score_a_change
            x_ball_change = -15
            y_ball += 1
            x_ball += x_ball_change

               #Winning the game
        if score_a == 10:
            screen.fill((0,0,0))
            font = pygame.font.Font(None,74)
            text = font.render("Player 1 Wins",True,white)
            screen.blit(text,(250,300))
            pygame.display.update()

        elif score_b == 10:
            screen.fill((0,0,0))
            font = pygame.font.Font(None,74)
            text = font.render("Player 2 Wins",True,white)
            screen.blit(text,(250,300))
            pygame.display.update()

                
            font = pygame.font.Font(None, 26)
            restart = font.render("Play Again", True, white)
            screen.blit(restart,(255,470))
            pygame.display.update()
           





        
    pygame.display.update()
    time.sleep(2)
    pygame.quit()

main()                
